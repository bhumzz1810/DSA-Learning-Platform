import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";

const navItems = [
  { label: "Home", path: "/" },
  { label: "Problems", path: "/problems" },
  { label: "Playground", path: "/playground" },
  { label: "Leaderboard", path: "/leaderboard" },
  { label: "Profile", path: "/profile" },
];

const radius = 140;

export default function RadialNav() {
  const [open, setOpen] = useState(false);
  const [clickedPath, setClickedPath] = useState(null);
  const navigate = useNavigate();

  const handleItemClick = (path) => {
    setClickedPath(path);
    setTimeout(() => {
      setOpen(false);
      setClickedPath(null);
      navigate(path);
    }, 1000);
  };

  return (
    <div className="fixed top-6 left-1/2 transform -translate-x-1/2 z-50">
      <button
        onClick={() => setOpen(!open)}
        className="w-14 h-14 rounded-full bg-blue-800 text-white flex items-center justify-center shadow-xl hover:scale-105 transition"
      >
        ☰
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            className="absolute top-0 left-1/2 transform -translate-x-1/2"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            {navItems.map((item, i) => {
              const total = navItems.length - 1;
              const angleDeg = -90 + (180 / total) * i; // spread items over a half circle
              const angleRad = (angleDeg * Math.PI) / 180;
              const x = Math.cos(angleRad) * radius;
              const y = Math.sin(angleRad) * radius;

              return (
                <motion.button
                  key={item.path}
                  className="absolute w-32 h-10 rounded-full bg-white shadow-md text-blue-800 font-semibold hover:bg-blue-100"
                  initial={{ x: 0, y: 0, opacity: 0, scale: 0 }}
                  animate={{
                    x,
                    y: -y,
                    opacity: 1,
                    scale: 1,
                    transition: { delay: i * 0.1, type: "spring" },
                  }}
                  exit={{
                    x: 0,
                    y: 0,
                    opacity: 0,
                    scale: 0,
                    transition: { delay: (total - i) * 0.1, type: "tween" },
                  }}
                  onClick={() => handleItemClick(item.path)}
                  disabled={!!clickedPath}
                >
                  {item.label}
                </motion.button>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
