import React from "react";

function Homepage() {
  return (
    <div className="p-8 text-center text-xl font-bold">
      Welcome to the Dashboard! 🚀
    </div>
  );
}
export default Homepage;
