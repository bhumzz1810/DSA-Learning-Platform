import React from "react";

function Dashboard() {
    return (
        <div className="p-8 text-center text-xl font-bold">
            <Sidebar />
            Welcome to the Dashboard! 🚀
        </div>
    );
    }
export default Dashboard;